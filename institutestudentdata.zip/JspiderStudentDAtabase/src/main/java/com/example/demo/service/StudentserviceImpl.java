package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.studentdao;
import com.example.demo.entity.Student;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class StudentserviceImpl implements Studentservice{
	@Autowired
	private studentdao studentDao;

	@Override
	public List<Student> getstudent() {
		// TODO Auto-generated method stub
		return studentDao.findAll();
	}

	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		 studentDao.save(student);
		 
		
	}

	@Override
	public void deletStudent(long parselong) {
		// TODO Auto-generated method stub
		Student entity =studentDao.getOne(parselong);
    	studentDao.delete(entity);
		
	}

	@Override
	public Optional<Student> getStudent(Long studentId) {
		// TODO Auto-generated method stub
		return studentDao.findById(studentId);
	}

	@Override
	public Optional<Student> findByEmailAndPassword(String email, String password) {
		// TODO Auto-generated method stub
		return studentDao.findByEmailAndPassword(email, password);
	}









	

	

}
