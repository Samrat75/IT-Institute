package com.example.demo.controller;

import com.example.demo.entity.Student;

import com.example.demo.service.Studentservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class MyController {

    @Autowired
    private Studentservice service;

    @RequestMapping("/index")
    public String home() {
        System.out.println("this is home page");
        return "index";
    }

    @GetMapping("/hom")
    public String hom() {
        return "home";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/course")
    public String course() {
        return "course";
    }

    @GetMapping("/placement")
    public String placement() {
        return "placement";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    @GetMapping("/signup")
    public String signup(Student student) {
        return "signup";
    }

    @GetMapping("/confirmation")
    public String confirmation(@RequestParam(required = false) String message, Model model) {
        model.addAttribute("message", message);
        return "confirmation";
    }

    @PostMapping("/check-login")
    public String checkLogin(@RequestParam String email, @RequestParam String password, Model model) {
        Optional<Student> student = service.findByEmailAndPassword(email, password);

        if (student.isPresent()) {
            model.addAttribute("message", "We have your data");
            return "redirect:/confirmation";
        } else {
            model.addAttribute("status", "User not found");
            return "redirect:/error";
        }
    }

    @PostMapping("/stud")
    public String addStudent(@ModelAttribute Student student) {
        service.addStudent(student);
        return "redirect:/confirmation";
    }

    @GetMapping("/student")
    @ResponseBody
    public List<Student> getStudents() {
        return this.service.getstudent();
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<Student> getStudent(@PathVariable String studentId) {
        try {
            Long id = Long.parseLong(studentId);
            return service.getStudent(id)
                    .map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/student/{studentId}")
    public ResponseEntity<HttpStatus> deleteCourse(@PathVariable String studentId) {
        try {
            this.service.deletStudent(Long.parseLong(studentId));
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
