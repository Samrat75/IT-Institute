package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.apache.catalina.User;

import com.example.demo.entity.Student;

public interface Studentservice {
 List<Student> getstudent();
 void addStudent(Student student);
 void deletStudent(long parselong);
 Optional<Student> getStudent(Long studentId);

 Optional<Student> findByEmailAndPassword(String email, String password);

}
